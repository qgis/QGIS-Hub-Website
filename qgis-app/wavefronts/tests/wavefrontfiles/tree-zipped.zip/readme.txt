A test tree for the QGIS Hub 3D viewer.
A box trunk and a cone canopy, with an embedded bark texture.
